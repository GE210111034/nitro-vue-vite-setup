<template>
  <div class="" size="h-screen" bg="red"></div>
</template>