export function useRef<T>(initialValue: T) {
  const r = ref<T>(initialValue)
  return [
    r,
    (v: T) => r.value = v
  ]
}