//https://nitro.unjs.io/config
export default defineNitroConfig({
  srcDir: "server",
  // renderer: 'src',
  devProxy: {
    "/src/pages/assets": "http://localhost:3000/src/assets",
  }
});
