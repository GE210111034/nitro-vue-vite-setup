import type { Connect, HmrOptions, ViteDevServer } from "vite";

interface ViteConfig {
  root: string;
  base: string;
  build: { outDir: string };
  server?: { hmr?: boolean | HmrOptions };
}
const _State = {
  viteConfig: undefined as ViteConfig | undefined,
};

const Config = {
  viteConfigFile: undefined as string | undefined,
};

export async function useViteConfig() {
  if (!_State.viteConfig) {
    const { resolveConfig } = await import("vite");
    try {
      const config = await resolveConfig({ configFile: Config.viteConfigFile }, "build");
      _State.viteConfig = config;
    } catch (e) {
      throw e;
    }
  }
  return _State.viteConfig;
}