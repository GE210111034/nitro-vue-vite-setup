import fs from "fs";
import path from "path";

export function useViteTemplate(reqPath: string, root: string) {
  if (reqPath.endsWith(".html")) {
    const pathToTest = path.join(root, reqPath);
    if (fs.existsSync(pathToTest)) return pathToTest;
  }

  const basePath = reqPath.slice(0, reqPath.lastIndexOf("/"));
  const dirs = basePath.split("/");

  while (dirs.length > 0) {
    const pathToTest = path.join(root, ...dirs, "index.html");
    if (fs.existsSync(pathToTest)) return pathToTest;
    dirs.pop();
  }

  return undefined;
} 