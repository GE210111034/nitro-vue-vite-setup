export default eventHandler((event) => {
  return "Start by editing <code>server/routes/index.ts</code>. sdfsd";
});
