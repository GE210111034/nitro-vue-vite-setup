import { createServer as createViteServer } from 'vite';
// import fs from 'fs';
export default defineNitroPlugin(async (nitroApp) => {
  const mode = process.env.NODE_ENV === 'production' ? 'production' : 'development';

  if (mode === 'development') {
    // const viteConfig = await useViteConfig();
    const viteServer = await createViteServer();
    nitroApp.hooks.hook('request', async (event) => {
      // console.log(event.path);
      if (!event.path.startsWith('/api')) {
        await new Promise<void>((resolve, reject) => {
          viteServer.middlewares(event.node.req, event.node.res, (err) => {
            if (err) reject(err);
            resolve();
          });
        });
      }
    });
    // nitroApp.router.use(viteConfig.base, eventHandler(async (event) => {
    //   const { req, res } = event.node;
    //   await new Promise<void>(async (resolve, reject) => {
    //     const templateFilePath = useViteTemplate(event.path, viteConfig.root);
    //     if (templateFilePath === undefined) return resolve();
    //     const template = fs.readFileSync(templateFilePath, "utf8");
    //     let html = await viteServer.transformIndexHtml(
    //       templateFilePath,
    //       template,
    //       req.originalUrl,
    //     );
    //     try {
    //       res.setHeader("Content-Type", "text/html");
    //       res.end(html);
    //       resolve();
    //     } catch (e) {
    //       console.error(e);
    //       res.statusCode = 500;
    //       res.end();
    //       reject(e);
    //     }
    //   });
    // }))
    nitroApp.hooks.hook('close', async () => {
      await viteServer.close();
    })
  }
});
