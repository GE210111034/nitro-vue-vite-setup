import { defineConfig } from 'vite'
import Vue from '@vitejs/plugin-vue'
import Pages from 'vite-plugin-pages'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import Unocss from '@unocss/vite'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    Unocss('uno.config.ts'),
    Vue(),
    Components({
      extensions: ['vue'],
      dirs: ['src/components'], 
      dts: 'src/components.d.ts',
    }),
    Pages({
      dirs: ['src/pages'],
    }),
    AutoImport({
      // include: [
      //   /\.[tj]sx?$/, // .ts, .tsx, .js, .jsx
      //   /\.vue\??/, // .vue
      // ],
      dts: 'src/auto-imports.d.ts',
      imports: [
        'vue',
        'vue-router',
        '@vueuse/core',
        // 'vue-i18n',
        // '@vueuse/head',
        // 'vue-demi',
        // 'pinia',
        // 'dayjs',
        // 'axios',
        // 'lodash',
        // 'vue-axios',
        // 'vue-router',
        // 'vue-i18n',
        // 'vue-meta
      ],
      dirs: [
        'src/composables',
        'src/utils',
        // 'src/constants',
        // 'src/layouts',
        // 'src/assets',
        // 'src/services',
        // 'src/components',
        // 'src/pages',
        // 'src/store',
        // 'src/router',
        // 'src/styles',
        // 'src/types',
        // 'src/plugins',
        // 'src/middlewares',
        // 'src/configs',
        // 'src/views',
      ]
    }),
  ],
  server: {
    middlewareMode: true,
  },
  build: {
    minify: 'terser',
    terserOptions: {
      compress: {
        // drop_console: true,
        // drop_debugger: true
      }
    }
  }
})
